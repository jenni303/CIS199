﻿/*  Grading ID: S5046
 *  Lab 5
 *  Due date: Oct 17, 2021
 *  CIS 199-50-4218
 *  
 *  This lab explores the use of sentinel controlled repetition
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Lab5
{
    class Program
    {
        static void Main(string[] args)
        {
            double temp; // input temparatures variable
            double totalValInput = 0; // total valid input
            double totalTemps = 0; // total temparatures
            double mean = 0; // mean temperatures
            const int LOWEST = -20; //lowest temparatures
            const int HIGHEST = 130;// highest temparatures
            const int STOP = 999; // number to stop the loop
            String temparature; // string input
            WriteLine("Enter temperatures from -20 to 130 (999 to stop)");
            Write("Enter temperature: ");
            temparature = ReadLine();
            double.TryParse(temparature, out temp);
            while (temp != STOP)  // loop when temparature is different than 999
            {
                if (!double.TryParse(temparature, out temp)) // filter if input is not a number
                {
                    WriteLine("Enter temperatures from -20 to 130. Please reenter temperature.");
                    Write("Enter temperature: ");
                    temparature = ReadLine();
                    double.TryParse(temparature, out temp);
                }
                else
                  if (temp >= LOWEST && temp <= HIGHEST) // filter when input between -20 to 130
                {
                    totalTemps += temp;
                    totalValInput++;
                    
                    Write(" Enter temperature: ");
                    temparature = ReadLine();
                    double.TryParse(temparature, out temp);
                }
         
                else // filter when input outside -20 and 130
                {
                    WriteLine("Valid temperatures range from -20 to 130. Please reenter temperature.");
                    Write("Enter temperature:");
                    temparature = ReadLine();
                    double.TryParse(temparature, out temp);
                }


            }

                if (totalValInput == 0) // mean need totalValInput different than 0, so if totalValInput is equal 0, mean is equal 0
                {
                    WriteLine($"You entered 0 valid temperatures.");
                    WriteLine($"The mean temperature is 0 degrees.");
                }
                else
                {
                    mean = totalTemps / totalValInput; //calculate mean temperature when totalValInput different than 0
                    WriteLine("You entered {0} valid temperatures.", totalValInput);
                    WriteLine("The mean temperature is {0:f1} degrees.", mean);
                }


            
        }
    }
}

