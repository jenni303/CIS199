"use strict"

/*
   New Perspectives on HTML5 and CSS3, 8th Edition
   Tutorial 9
   Coding Challenge 1

   Clock
   Author: Jiani Wu
   Date:  11/9/2022 

   function getWeekday(dayNum)
      Returns the text of the day of the week where dayNum
      is the number of the week from 0 (Sunday) to 6 (Saturday)
*/

// calls the function runClock every 1 second(1,000 Milliseconds = 1 Second)
setInterval(runClock, 1000);
 
function runClock(){
  // thisDay is a Date object
  var thisDay = new Date();
 
  // calling thisDays Date object's toLocaleDateString() method to
  // get current date as string dd/mm/yyyy
  var thisDate = thisDay.toLocaleDateString();
 
  // calling thisDays Date object's getDay() method to
  // get current day 0 for sunday 1 for monday ..etc
  var thisDayNum = thisDay.getDay();
 
  // gets curresponding day name
  var thisWeekday = getWeekday(thisDayNum);
 
  // calling thisDays Date object's toLocaleTimeString() method to
  // get current time as string hh-mm-ss AM/PM
  var thisTime = thisDay.toLocaleTimeString();
 
  // Set the textContent of element with id "date" to thisDate(current date)
  document.getElementById("date").textContent = thisDate;
 
  // Set the textContent of element with id "wday" to thisDate(current day name)
  document.getElementById("wday").textContent = thisWeekday;
 
  // Set the textContent of element with id "time" to thisDate(current time)
  document.getElementById("time").textContent = thisTime;
}

function getWeekday(dayNum) {
   var wDays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
   return wDays[dayNum];
}
