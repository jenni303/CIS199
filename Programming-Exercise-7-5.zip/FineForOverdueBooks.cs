using System;
using static System.Console;
using System.Globalization;
public class FineForOverdueBooks
{
   public static void Main()
   {
   double days, books;
        Console.WriteLine("Enter the number of books");
        books = double.Parse(Console.ReadLine());
        Console.WriteLine("Enter the number of days");
        days = double.Parse(Console.ReadLine());
        DisplayFine(books, days);
   }
   public static void DisplayFine(double books, double days)
   {
           double fine = 0;
        if (days <= 7)
            fine = days * books * .10;
        else
            fine = books * (.70 + (days - 7) * .20);
        Console.Write("The fine for {0} book(s) for {1} day(s) is {2}", books, days, fine.ToString("C"));
   }
}
