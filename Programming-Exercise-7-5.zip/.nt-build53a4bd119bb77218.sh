rm -f *.exe
mcs FineForOverdueBooks.cs
