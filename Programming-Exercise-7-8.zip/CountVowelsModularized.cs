using System;
using static System.Console;
class CountVowelsModularized
{
   public static void Main()
   {
String str;
Console.Write("Input the string : ");
str = Console.ReadLine();
Console.WriteLine("\nNumber of vowels {0}",
+ CountVowels(str));
Console.ReadLine();    
}
   public static int CountVowels(string phrase)
   {

int length = value.length;
int count = 0;
for (int i = 0; i < length; i++)
{
if (value[i] == 'a' || value[i] == 'A' ||
    value[i] == 'e' || value[i] == 'E' ||
    value[i] == 'i' || value[i] == 'I' ||
    value[i] == 'o' || value[i] == 'O' ||
    value[i] == 'u' || value[i] == 'U')
count++;
}
return count;
}
}
 
